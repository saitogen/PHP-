<?php
    print"ご購入ありがとうございました"
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <form method="post" action="kadai01.php">
    <input type="submit" name="sub" value="ログアウトする">
    </form>
</body>
</html>